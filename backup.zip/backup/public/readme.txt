# Live Backup

Backup of live software application including removed data or media files of the users.