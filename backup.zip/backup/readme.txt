# Backup

Notes on how the backup system works, where the backup is stored, how to retrive and/or destroy previous backups. 